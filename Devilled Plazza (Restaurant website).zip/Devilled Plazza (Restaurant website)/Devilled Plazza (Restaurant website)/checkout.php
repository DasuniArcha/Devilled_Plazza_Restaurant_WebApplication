<?php
$connection = mysqli_connect("localhost", "root", "", "devilled_plazza");

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

?>


<!DOCTYPE html>
<html>
    <head>
        <title>Devilled Plazza</title>
        <link rel="icon" type="image/x-icon" href="logo.jpeg">
        <link rel="stylesheet" href="css/style.css">
        <style>

            .card {
                display: inline-block;
                margin: 10px;
                border: 1px solid #ddd;
                border-radius: 5px;
                padding: 15px
                text-align: center;
            }

            #image {
                padding: 10px;
                width: 200px;
                height: 175px;
            }

            #title, #price {
                margin: 5px;
                color: white;
            }

            #place-order-btn {
                position: fixed;
                bottom: 20px;
                left: 50%;
                transform: translateX(-50%);
                background-color: #e47907;
                color: white;
                padding: 10px 20px;
                border: none;
                border-radius: 5px;
                cursor: pointer;
            }

        </style>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    </head>
    <body background="https://images.creativemarket.com/0.1.0/ps/7065029/1820/965/m1/fpnw/wm1/fskqsdmhcmtrnadgcmunaflw1nh5tavkkv3n4kztdzp8kbz3mdyso1yajjfq2c1o-.jpg?1569963940&s=bc72ef9863a09c077c9806ae416074af">

          
        <section class="ourmenu">
            <h1>checkout</h1>
        </section><br>


        <div class="card">
            <h2 id="title">Item: ' . $itemName . '</h2>
            <h3 id="price">Price: Rs ' . $row['price'] . '.00</h3>
        </div>


        <button id="place-order-btn" onclick="location.href='';">Place Order</button>




    </body>
</html>