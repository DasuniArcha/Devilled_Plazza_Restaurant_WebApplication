<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/signin.css">
    <title>Login</title>
</head>
<body>
   <nav>
        <ul>
            <nav class="top-right-nav">
                <li><a href="index.php" id="home-link">Home</a></li>
                <li><a href="mainmenu.php" id="tickets-link">Menu</a></li>
                <li><a href="aboutus.html" id="contact-link">About Us</a></li>
        </ul>
    </nav>


    <div class="body-container">
        <form id="signin-form" method="post" action="signin.php">
            <h2>Login</h2><br>
            <input type="text" id="signin-username" placeholder="Email" name="email" required>
            <input type="password" id="signin-password" placeholder="Password" name="password" required><br><br>
            <h3 id="h3"></h3>
            <button type="submit" name="submit">Login</button><br><br> OR <br><br>
            <button><a href="register.html">Register Now</a></button>
        </form>
    </div>

    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="footer-col">
                    <ul>
                        <li><img src="logo.jpeg" width="100px" height="auto"></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Order Now</h4>
                   <ul>
                    <li><a href="signin.php">Place Order</a></li>
                   </ul>
                </div>
                <div class="footer-col">
                    <h4>About Us</h4>
                    <ul>
                        <li><a href="aboutus.html">Send Feedback</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Follow Us</h4>
                    <div class="socialmedia">
                        <ul>
                            <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</body>
</html> -->


<?php
session_start();

$connection = mysqli_connect("localhost", "root", "", "devilled_plazza");

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_POST['submit'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $admin_email = "admin@gmail.com";
    $admin_password = "admin123"; 

    if($email == $admin_email){
        if($password == $admin_password){
            header('Location: adminPage.html');
        }else{
            $_SESSION['error'] = 'Invalid Email or Password';
            header('Location: signin.html');
        }
        
    }else{
        $query = "SELECT * FROM user_details WHERE Email = ?";
        $stmt = mysqli_prepare($connection, $query);
        mysqli_stmt_bind_param($stmt, "s", $email);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if ($row = mysqli_fetch_assoc($result)) {
            $hashed_password = $row["password"];
    
            if (password_verify($password, $hashed_password)) {
                header('Location: index.html');
    
            } else {
                $_SESSION['error'] = 'Invalid Email or Password';
                exit();
            }
        } else {
            $_SESSION['error'] = 'Invalid Email or Password';
            exit();
        }
    }
    
    mysqli_stmt_close($stmt);
}

mysqli_close($connection);
?>