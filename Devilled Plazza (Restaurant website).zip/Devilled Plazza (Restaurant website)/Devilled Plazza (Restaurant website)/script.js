
const navbar = document.querySelector('nav');

menu.onclick = () =>{
   
   navbar.classList.toggle('active');
};

window.onscroll = () =>{
   
   navbar.classList.remove('active');
};


document.querySelector('#close-edit').onclick = () =>{
   document.querySelector('.edit-form-container').style.display = 'none';
   window.location.href = 'admin.php';
};

function addToCart(item){
    console.log(item)
}





function addToCart(item){
    console.log(item)
    let cartItems = localStorage.getItem("cartItems");

    // Check if cartItems is null or not
    if (cartItems === null) {
        // If cartItems is null, initialize it as an empty array
        cartItems = [];
    } else {
        // If cartItems is not null, parse it from JSON to array
        cartItems = JSON.parse(cartItems);
    }
    item["qty"] = 1;
    console.log(item)

    // Push the new item to the cartItems array
    cartItems.push(item);

    // Store the updated cartItems array in localStorage
    localStorage.setItem("cartItems", JSON.stringify(cartItems));

    // Display a success message
    displayMessage("Item added to cart successfully");
    console.log(cartItems);
}

function displayMessage(message) {
    alert(message);
}