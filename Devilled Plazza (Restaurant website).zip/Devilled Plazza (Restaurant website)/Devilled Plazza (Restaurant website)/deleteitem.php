<?php

$connection = mysqli_connect("localhost", "root", "", "devilled_plazza");

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}


if (isset($_POST['itemID'])) {
    $itemID = $_POST['itemID'];

    
    $query = "DELETE FROM items WHERE itemID = $itemID";

    if (mysqli_query($connection, $query)) {
        echo "<h1>Item deleted successfully.</h1>";
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($connection);
    }
} else {
    
    echo file_get_contents('deleteitem.php');
}


mysqli_close($connection);
?>
