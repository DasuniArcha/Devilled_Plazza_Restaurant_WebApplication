<?php

$connection = mysqli_connect("localhost", "root", "", "devilled_plazza");

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}



$query = "SELECT * FROM user_details ";
$result = mysqli_query($connection, $query);

if (mysqli_num_rows($result) > 0) {
    echo "<h1>Users List</h1>";
    echo "<table border='2' style='color: white; background-color: gray;'>";
   
    
    echo "<tr><th>ID</th><th>FirstName</th><th>LastName</th><th>Email</th>
        <th>Gender</th><th>Address</th><th>ContactNo</th></tr>";


    while ($row = mysqli_fetch_assoc($result)) {
      
        
       echo "<tr><td>{$row['UserId']}</td><td>{$row['FirstName']}</td><td>{$row['LastName']}</td><td>{$row['Email']}</td>
            <td>{$row['Gender']}</td><td>{$row['Address']}</td><td>{$row['ContactNo']}</td></tr>";
    }
    

    echo "</table>";
} else {
    echo "<h1>No users found.</h1>";
}



mysqli_close($connection);
?>