<?php

$connection = mysqli_connect("localhost", "root", "", "devilled_plazza");

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}



$query = "SELECT * FROM items ";
$result = mysqli_query($connection, $query);

if (mysqli_num_rows($result) > 0) {
    echo "<h1>Item List</h1>";
    echo "<table border='2' style='color: white; background-color: gray;'>";

   
    
    echo "<tr><th>Item ID</th><th>Item Name</th><th>Price</th></tr>";


    while ($row = mysqli_fetch_assoc($result)) {
      
        
       echo "<tr><td>{$row['itemId']}</td><td>{$row['itemName']}</td><td>{$row['price']}</td></tr>";
    }
    

    echo "</table>";
} else {
    echo "<h1>No Item found.</h1>";
}



mysqli_close($connection);
?>