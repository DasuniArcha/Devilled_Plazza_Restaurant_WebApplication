<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="css/adduser.css">
    <title>Remove Item</title>
</head>

<body>

    <h1>Remove Item</h1>

    <form action="deleteitem.php" method="POST">
        <label for="itemID">Select a Item For Remove:</label><br>
        <select name="itemID" required>
            <option value="">Select Item</option>

            <?php
            
            $connection = mysqli_connect("localhost", "root", "", "devilled_plazza");

            if (!$connection) {
                die("Connection failed: " . mysqli_connect_error());
            }

            
            $query = "SELECT * FROM items";
            $result = mysqli_query($connection, $query);

            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<option value='{$row['itemId']}'>{$row['itemName']}</option>";
                }
            }

            
            mysqli_close($connection);
            ?>

        </select><br><br>

        <button type="submit">Remove</button>

    </form>

</body>

</html>