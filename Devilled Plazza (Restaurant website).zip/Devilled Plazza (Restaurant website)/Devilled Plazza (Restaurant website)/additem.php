<?php

$connection = mysqli_connect("localhost", "root", "", "devilled_plazza");

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}




$itemName = $_POST['itemName'];
$price = $_POST['price'];


$target_dir = "upload_images/"; // Directory where you want to store uploaded images
$image_path = $target_dir . basename($_FILES['itemImage']['name']);

$query = "INSERT INTO items (itemName, price, image_path) VALUES ( '$itemName', '$price', '$image_path')";

if (mysqli_query($connection, $query)) {
    echo "item added successfully.";
} else {
    echo "Error: " . $query . "<br>" . mysqli_error($connection);
}

mysqli_close($connection);

?>